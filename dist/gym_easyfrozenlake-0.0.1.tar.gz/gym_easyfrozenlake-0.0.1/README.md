Modified Frozen Lake gym environment to make it easier

### Deterministic
- is_slippery is set to false, hence you'll always go to direction you wanted

### Rewads
- -1 reward when you fall to hole
- +1 reward when you step on frozen lake
- +5 when you reach goal